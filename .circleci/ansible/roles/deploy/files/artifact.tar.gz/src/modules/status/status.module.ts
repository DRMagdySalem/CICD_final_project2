import { Module } from '@nestjs/common';

@Module({})
export class StatusModule {}
